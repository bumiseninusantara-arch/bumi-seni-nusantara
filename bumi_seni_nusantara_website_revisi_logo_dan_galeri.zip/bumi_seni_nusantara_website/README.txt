BUMI SENI NUSANTARA — Website

Cara melihat secara lokal:
1. Ekstrak ZIP.
2. Buka folder bumi_seni_nusantara_web_final.
3. Buka index.html menggunakan Chrome.

Isi:
- Logo resmi BUMI SENI NUSANTARA.
- Halaman profil, layanan, dokumentasi karya, proses kerja, tim, dan kontak.
- Foto dokumentasi yang tersedia di folder assets.

Catatan: Website ini merupakan paket revisi. Untuk mengganti versi yang tampil di alamat online, paket ini masih perlu diterbitkan (deploy) ke proyek hosting Vercel.
